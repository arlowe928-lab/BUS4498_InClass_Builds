---
name: company-research
description: Research a company (financials, headcount, competitors) and write the findings into Ethan's Notion "Company Research" database. Use this whenever Ethan asks to research, look up, profile, or add a company (e.g. "research Ramp for my company research db", "add Anthropic to Notion", "can you fill out the company research page for Stripe", "look into Brex's financials and competitors"), even if he doesn't mention Notion explicitly by name — if the request is about researching a company for tracking/comparison purposes, this skill applies.
---

# Company Research → Notion

Ethan keeps a Notion database called **Company Research** (data source: `collection://42a3a5c3-d6db-4f5f-8d1a-0a8495df6438`) where each row profiles one company. This skill researches a company across the web and writes the findings into that database, matching the depth and style of the existing reference entry (Ramp).

## Workflow

### 1. Confirm the database and its current schema

Fetch the database before writing anything — Ethan may have added, renamed, or removed columns since this skill was written, and writing against a stale schema will silently drop data or throw errors.

- `notion-search` for "Company Research" if the data source URL above doesn't resolve.
- `notion-fetch` the data source to get the live property list, types, and the current option sets for `Sector`, `Public/Private`, and `Key Competitors`.

The schema as of this writing:

| Property | Type | Notes |
|---|---|---|
| Company | title | Company name |
| Sector | select | Technology, Finance, Healthcare, Retail, Manufacturing, Energy, Media, Other |
| Public/Private | select | Public, Private |
| Headquarters | text | City, State/Country |
| Year Founded | number | |
| Revenue | number (dollar) | Raw dollar amount, e.g. `1400000000`, not a string like "$1.4B" |
| Revenue Growth % YoY | number (percent) | Store as a decimal fraction — `0.71` means 71%, `1` means 100%. State the comparison years in Notes (step 5) — the property itself can only hold the number |
| Net Income | number (dollar) | |
| Headcount | number | |
| Headcount Growth % YoY | number (percent) | Same decimal-fraction convention as above. State the comparison years in Notes (step 5) — the property itself can only hold the number |
| Key Competitors | multi-select | See step 4 for adding new options |
| Notes | text | See step 5 for what goes here |
| Last Updated | date | Set to today |

If the live schema differs from this table, trust the live schema.

### 2. Check whether the company already has a row

Before creating anything, query the database (`notion-query-database-view` on the default view, or `notion-search` scoped to the data source) for a page whose `Company` title matches. Matching should be case-insensitive and tolerant of minor naming variants (e.g. "Ramp" vs "Ramp Business Corporation").

- **Found a match** → update that page (`notion-update-page`) rather than creating a duplicate.
- **No match** → create a new page in the data source (`notion-create-pages`).

### 3. Research the company

Use web search across multiple sources rather than settling for the first hit — company financials in particular vary by source and by whether the company is public or private.

- **Public companies**: pull Revenue and Net Income from the most recent 10-K/10-Q or official investor relations page. Priotize using https://www.sec.gov/edgar/search/.
- **Private companies**: revenue/valuation are typically self-reported or estimated (Crunchbase, PitchBook summaries, press coverage of funding rounds). Note when a figure is an estimate or when sources disagree, rather than presenting a guess as fact.
- **Headcount**: LinkedIn company page, Growjo, or recent press are reasonable sources for a current snapshot; note the approximate date the figure reflects, since headcount pages are often stale. For **Headcount Growth % YoY**, don't rely on a source that states a growth rate directly (these are rare and often stale) — instead find two comparable numbers roughly a year apart from the *same kind* of source (e.g. this year's 10-K/annual-report headcount vs. the same filing a year earlier, or two LinkedIn/Growjo snapshots ~12 months apart) and compute the percent change yourself: `(new - old) / old`. Pairing mismatched sources for the two data points (say, this year's 10-K against last year's LinkedIn estimate) produces a number that looks precise but isn't actually comparing like with like — skip the growth figure rather than do that. Also skip it (noting why in Notes) if a major one-off headcount event — a layoff, an acquisition, a big hiring push — falls inside the comparison window, since a same-period YoY number would be misleading even with two clean, matched data points; that's why it's blank on Intuit's row right now, mid-restructuring.
- **Key Competitors**: G2/Capterra category rankings, industry analyst comparisons, or reputable business press.
- **Recent news**: funding rounds, major leadership changes, product launches, or other headline events from the last several months. This gets its own Recent News section (step 7) rather than being folded into Notes.
- **Product lineup**: as you research, form a clear picture of what the company actually makes or does day-to-day — not just which of the 8 broad Sector buckets it falls into. Two companies can share a Sector (both "Finance") but do very different things (a corporate card issuer vs. a consumer bank vs. a trading platform). You'll use this understanding twice: condensed into the Company Overview paragraph (step 6), and spelled out in more detail in the Products & Services section (step 8).

Skip fields you genuinely can't find a reasonable source for rather than inventing a number — an empty field is honest; a fabricated one isn't.

### 4. Handle Key Competitors options

If a competitor you want to add isn't already one of the existing multi-select options, add it as a new option (rather than skipping it or forcing it into an existing option that doesn't fit). Keep the list focused — 3-5 direct competitors is more useful than an exhaustive list.

**A new competitor name can't just be dropped into the page's `Key Competitors` array — `notion-create-pages`/`notion-update-page` will reject any multi-select value that isn't already a defined option.** The schema has to be extended first, in a separate step, before the page property will accept it:

1. Fetch the data source (step 1) to get the current full list of `Key Competitors` options.
2. Call `notion-update-data-source` with `statements: 'ALTER COLUMN "Key Competitors" SET MULTI_SELECT(\'Existing1\':color, \'Existing2\':color, ..., \'NewName\':color)'` — this must list every existing option plus the new one(s), since it replaces the option set rather than appending to it. Pick colors not already in use where possible.
3. Only after that call succeeds, set the page's `Key Competitors` property (via `notion-create-pages` or `notion-update-page`'s `update_properties` command) to the array of names you actually want on this row.
4. `notion-fetch` the page you just wrote and confirm `Key Competitors` shows exactly what you intended. This step is worth the extra call — testing found cases where the schema update silently didn't take effect and the page property ended up blank despite the write appearing to succeed, so treat "I called the tool" as different from "the data actually landed."

### 5. Write the Notes field

Notes is where nuance that doesn't fit a structured field goes. Follow the pattern from the existing Ramp entry for content — call out when a figure is an estimate or when sources disagree (and what range they disagree over), and flag anything a reader might otherwise misinterpret (e.g. a similarly-named but unrelated company) — but keep the format tighter than a paragraph: write it as short bullet points, one caveat or fact per line, rather than flowing prose. Brevity matters more than completeness here; if a caveat needs more than a sentence, it probably belongs as two bullets instead of one long one. Recent news goes in its own section (step 7), not here.

**Whenever you mention Revenue Growth % YoY or Headcount Growth % YoY, state the exact years being compared right next to the percentage** — e.g. `+12% (2024-2025)` — rather than a bare percentage. The property itself can only store the number, not which two periods it's comparing, and a growth rate is close to meaningless without knowing whether it's calendar-year, fiscal-year, or something else; Notes is where that context has to live. This applies any time the figure appears in Notes, not just the bullet where it's first introduced.

### 6. Write the Company Overview

Before Ethan gets to news and product details, give him a quick orientation: a short paragraph (3-4 sentences) summarizing what the company actually does, sells, or offers. This is the first thing he sees when he opens the page, so it should stand on its own — someone who reads only this paragraph should walk away knowing what business the company is in, who it serves, and what its core offering is, without needing the rest of the page.

Unlike the other page sections, write this as flowing prose, not bullets — a short paragraph reads more naturally as an orientation than a list of fragments would. Draw on the same product-lineup research from step 3 rather than treating this as a separate research pass; think of it as the condensed, narrative version of what the Products & Services section (step 8) lays out in more detail.

Example:

```markdown
## Overview
Ramp is a corporate spend management platform that combines corporate cards, expense management, and bill pay into a single system aimed at helping businesses control spend and close their books faster. It primarily serves venture-backed startups and mid-market companies, and competes with both legacy card issuers like American Express and newer fintech entrants like Brex. Ramp differentiates on real-time spend controls and automated expense categorization, positioning itself as a finance operating system rather than just a card issuer.
```

- **New page**: put this `## Overview` block at the very start of the `content` string, ahead of Recent News (step 7), Products & Services (step 8), and Sources (step 9).
- **Existing page being updated**: if it doesn't exist yet, `notion-fetch` the page and `insert_content` with `position: {"type": "beginning"}` (or find the current first block and insert `before` it, if the tool only supports positioning relative to an existing block). If an Overview section already exists from a previous update, use `update_content` to replace it in place.

### 7. Write the Recent News section

Recent developments — funding rounds, major leadership changes, product launches, or other headline events from the last several months — are what Ethan is most likely to want to skim next after the Overview, so they get a dedicated **Recent News** section in the page body (not a property), placed right after the Company Overview (step 6) and ahead of Products & Services (step 8) and Sources (step 9).

Format it as short bullets, most recent first, and **link each bullet to the article it came from** — Ethan shouldn't have to jump down to Sources just to read the piece a headline is based on:

```markdown
## Recent News
- Raised $150M Series D at a $3.25B valuation, led by [Investor], March 2026 ([TechCrunch](https://techcrunch.com/...))
- Named [Name] as new CFO, succeeding [Prior], January 2026 ([company press release](https://example.com/...))
```

If a bullet draws on more than one article, link both, e.g. `([CNBC](url1), [TechCrunch](url2))`. Reuse the same URLs in the Sources section (step 9) — the two sections serve different purposes (skimmability here, full citation there), not two independently-researched lists.

Skip the section entirely if nothing notable turned up in the last several months — an absent section reads better than a bullet saying there's nothing to report.

- **New page**: in the same `content` string passed to `notion-create-pages`, list the blocks in page order — `## Overview`, then `## Recent News`, then `## Products & Services`, then `## Sources` — since the order of blocks in that one Markdown blob is the order Notion renders them in.
- **Existing page being updated**: if Recent News doesn't exist yet, insert it directly after the Company Overview section (or at the very start if there's no Overview yet either). `notion-fetch` the page to find the right anchor block and insert before/after it accordingly. If a Recent News section already exists from a previous update, use `update_content` to replace it in place — no need to touch its position.

### 8. Write the Products & Services section

Ethan often can't recall the specifics of what a company actually sells just from its Sector — two "Finance" companies can have completely different products. This section spells that out in more detail than the Overview paragraph does: a bullet list of the company's actual products or services, each with a one-line description of what it does. It draws on the same product-lineup research from step 3 that fed the Overview (step 6) — this section just itemizes that understanding instead of condensing it into a paragraph.

Format it as a bullet list, one product/service per line, most important or flagship offering first:

```markdown
## Products & Services
- **QuickBooks** — small business accounting and bookkeeping software
- **TurboTax** — consumer tax preparation software
- **Credit Karma** — free credit monitoring and personalized financial recommendations
- **Mailchimp** — email marketing and marketing automation platform
```

Keep each line to one sentence — this is an orientation aid, not a product catalog. For a company with a single core product, one bullet is fine. This section sits between Recent News and Sources in the page body.

- **New page**: put the `## Products & Services` block after `## Recent News` and before `## Sources` in the same `content` string.
- **Existing page being updated**: if it doesn't exist yet, `notion-fetch` the page to find the Recent News section's ending block (or Sources' starting block, whichever exists) and `insert_content` right between them. If it already exists, `update_content` to replace it in place.

### 9. List sources in the page content

The database properties don't have room to show where each fact came from, but that's exactly what Ethan needs to actually trust or double-check a row later. So every row also gets a **Sources** section written into the page's body content (not a property) listing what was used and, in a short blurb, what each one specifically established — not just a link dump. This section comes last in the page body, after Company Overview (step 6), Recent News (step 7), and Products & Services (step 8).

Format it as a bullet list, one source per line:

```markdown
## Sources
- [Anthropic company page](https://anthropic.com/company) — founding year, HQ location
- [TechCrunch, May 2026](https://techcrunch.com/...) — Series H valuation and investor list
- Revelio Labs workforce data (via Sacra) — headcount trajectory estimate, since Anthropic doesn't disclose headcount directly
```

Link to the source where you have a real URL; for aggregator/estimate sources without a stable link, just name them. The blurb after the dash is the point — it tells Ethan whether a source backs a hard fact or just an estimate, so he can judge how much to trust each figure without re-doing the research himself. Reuse the same URLs you already linked inline in Recent News (step 7) rather than re-finding them — this section is the fuller citation list, not a separate research pass.

- **New page**: pass this section as part of the `content` parameter to `notion-create-pages`, after the Company Overview, Recent News, and Products & Services blocks (Notion-flavored Markdown; don't repeat the page title in the content).
- **Existing page being updated**: use `notion-update-page`'s `insert_content` (with `position: {"type": "end"}`) to append a Sources section if one doesn't exist yet. If the page already has a Sources section from a previous update, use `update_content` to replace it rather than appending a second one.

### 10. Verify sources with an independent check

Once the page is written (steps 3-9 done), spawn a subagent to independently double-check that the sources actually say what the page claims they say. The research and the writing all happened in one continuous context, which makes it easy for a plausible-sounding figure or a garbled citation to slip through unnoticed — a fresh subagent with no stake in the draft is much better at catching a claim that doesn't actually hold up than the same context that just produced it.

Give the subagent:
- The finalized structured values (Revenue, Net Income, Headcount, Headcount Growth % YoY, Revenue Growth % YoY, Year Founded, Headquarters, Key Competitors).
- The Notes bullets, the Company Overview paragraph, the Recent News bullets (with their inline links), and the Sources section, exactly as written.
- Instructions to fetch every URL cited (in Recent News links and in Sources) and check, source by source, whether the specific number or claim attributed to it is actually present there — not just that the link resolves. A dead link, a source that exists but says something different, or a source that doesn't mention the claim at all are all things to flag.
- Instructions to report back per-claim, not just a single verdict — which facts checked out, which didn't, and why — so it's clear exactly what (if anything) needs fixing rather than a vague "looks fine" or "something's off."

Treat what comes back as something to act on, not just read. If the subagent flags a mismatch, go fix it: correct the figure, find a source that actually supports it, or remove the claim if it can't be substantiated, then update the already-written page (`update_properties`/`update_content`) to match. If something can't be resolved with confidence, don't just drop it silently — surface it to Ethan in step 11 so he knows a figure is shakier than the rest of the row.

### 11. Confirm back to Ethan

After writing the row, tell Ethan which company was added/updated. Always end this confirmation with an explicit call-out of anything you skipped or couldn't verify — which fields you left blank and why, figures that were rough estimates rather than confirmed numbers, any new competitor options you added, and anything the source-verification pass (step 10) flagged that you couldn't fully resolve. Don't bury this in the middle of a longer explanation; make it the last thing he reads, since it's the part he's most likely to act on (e.g. by telling you to dig further on a specific field).

## Researching multiple companies

If asked to research several companies in one go, process them one at a time (search → research → check for duplicate → write), rather than batching all the research before writing anything — this way if something goes wrong partway through, the companies already done are still saved.
